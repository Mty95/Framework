<?php

namespace PHPSTORM_META {

    expectedArguments(
        \Framework\Libraries\Twig::display(),
        0,
        'a',
        'b'
    );

    exitPoint(\redirect());
}
