<?php
/** @var Routes $routes */

use Framework\Framework;
use Framework\Routing\RouteCollection as Routes;

$routes = Framework::instance()->getAppRouteCollection();
$routes->get('/', 'HomeController@index');