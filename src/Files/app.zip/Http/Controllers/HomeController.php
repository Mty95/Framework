<?php
namespace App\Http\Controllers;

use App\Models\User\Repository;
use App\Models\User\User;
use Framework\Support\Http\Controller;
use Framework\Support\Http\Request;
use Framework\Support\Http\ResponseInterface;

class HomeController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(Request $request): ResponseInterface
    {
        return $this->render('@app/home.twig');
    }
}
