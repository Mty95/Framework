<?php
namespace App\Http\Filters;

use Framework\Filters\FilterInterface;
use Framework\Support\Http\RequestInterface;
use Framework\Support\Http\ResponseInterface;

class WebFilter implements FilterInterface
{

    public function before(RequestInterface $request)
    {
    }

    public function after(RequestInterface $request, ResponseInterface $response)
    {
        // TODO: Implement after() method.
    }
}
