<?php
namespace App;

use App\Http\Filters\WebFilter;

class Config
{
    public array $psr4 = [
        'Framework' => FRAMEWORK_PATH,
        'App' => APPPATH,
    ];

    public array $assetsToPublish = [];

    public array $filters = [
        'web' => WebFilter::class,
    ];

    /**
     * Twig template files with namespaces.
     *
     * Do not forget to add Namespace in PhpStorm config
     * Symfony/Twig Template.
     *
     * @var array
     */
    public array $twig = [
        'app' => APPPATH . 'Views',
    ];

    /**
     * @var array
     */
    public array $debug = [
        'debug_blacklist' => [
            '_ENV' => [
                'database.development.password',
                'database.testing.password',
                'database.production.password',
            ]
        ],
    ];

    /**
     * The listener classes to register.
     *
     * If you need to registry a lot of
     * listeners on same event, then
     * use subscriber class instead.
     *
     * @return array
     */
    public function listeners()
    {
        return [
        ];
    }

    /**
     * The subscriber classes to register.
     *
     * @return array
     */
    public function subscribers()
    {
        return [
        ];
    }
}
